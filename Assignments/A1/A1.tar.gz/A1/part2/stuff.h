#define G 92

void print_pyramid(int pyramidSize);
