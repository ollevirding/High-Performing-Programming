echo Hej hej
echo Vad heter du
echo Mitt namn är Tom Dolder

